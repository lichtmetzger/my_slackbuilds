/* This is a stub header to avoid having to change tess.c */
