#ifndef __GLIB_OBJECT_H__
#define __GLIB_OBJECT_H__

#include "glib.h"

#endif /* __GLIB_OBJECT_H__ */
