
assert(bit.toggleBit(0xF, 0) == 0xE)
assert(bit.toggleBit(0, 0) == 1)
