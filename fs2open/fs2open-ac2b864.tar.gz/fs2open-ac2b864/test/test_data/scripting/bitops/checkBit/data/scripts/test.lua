
assert(bit.checkBit(0xF, 0) == true)
assert(bit.checkBit(0, 0) == false)
