
assert(bit.addBit(0xE, 0) == 0xF)
assert(bit.addBit(0, 0) == 1)
assert(bit.addBit(1, 0) == 1)
