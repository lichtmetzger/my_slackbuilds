
assert(MESSAGE_PRIORITY_LOW ~= nil)
