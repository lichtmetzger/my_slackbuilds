//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by freespace.rc
//
#define IDD_DEBUG_MENU                  101
#define IDD_CONNECT                     108
#define IDD_MULTI                       109
#define IDC_CURSOR1                     111
#define IDC_CURSOR2                     112
#define IDD_PLAYER_DIALOG               114
#define IDD_GODSTUFF                    115
#define IDD_DEBUG_DIALOG                116
#define IDB_GOAL_INC                    118
#define IDB_GOAL_COMP                   119
#define IDB_GOAL_ORD                    120
#define IDB_GOAL_NONE                   121
#define IDB_GOAL_FAIL                   122
#define IDI_APP_ICON                    124
#define IDI_APP_ICON_GLOW               125
#define IDD_GEN                         127
#define IDD_RT_VSELECT                  128
#define IDD_DIALOG1                     129
#define IDR_CMD_CFG                     132
#define IDC_LIST_DEBUG                  1000
#define IDC_DEBUG_TEXT1                 1001
#define IDC_DEBUG_TEXT2                 1002
#define IDC_TEXT                        1003
#define IDC_HOST_IS                     1005
#define IDC_CONPING                     1007
#define IDC_RESET_MULTI                 1011
#define IDC_STANDALONE_STATE            1012
#define IDC_STATIC_A                    1013
#define IDC_STANDALONE_FPS              1014
#define IDC_STATIC_A2                   1015
#define IDC_STANDALONE_MTIME            1016
#define IDC_PLAYER_LIST                 1016
#define IDC_PSHIP_TYPE                  1017
#define IDC_NETPLAYER_NUM               1018
#define IDC_PHITS                       1019
#define IDC_PBHHITS                     1020
#define IDC_PPCT                        1021
#define IDC_PBHPCT                      1022
#define IDC_SSHOTS                      1023
#define IDC_MPSHOTS                     1024
#define IDC_PLAYER_GOD_LIST             1026
#define IDC_SECHITS                     1028
#define IDC_SBHHITS                     1029
#define IDC_SPCT                        1030
#define IDC_SBHPCT                      1031
#define IDC_MPHITS                      1032
#define IDC_MPBHHITS                    1033
#define IDC_MPPCT                       1034
#define IDC_MPBHPCT                     1035
#define IDC_MSSHOTS                     1036
#define IDC_MSECHITS                    1037
#define IDC_MSBHHITS                    1038
#define IDC_MSPCT                       1039
#define IDC_MSBHPCT                     1040
#define IDC_PSHOTS                      1041
#define IDC_PING_TIME                   1042
#define IDC_MISSION_NAME                1043
#define IDC_GODSTUFF_BROADCAST          1044
#define IDC_GODSTUFF_SENDMESS           1045
#define IDC_STD_GOALS                   1049
#define IDC_PLAYER_MESSAGES             1051
#define IDC_ASSISTS                     1052
#define IDC_MASSISTS                    1053
#define IDC_KICK_BUTTON                 1054
#define IDC_STD_NAME                    1055
#define IDC_NG_MAXPLAYERS               1057
#define IDC_NG_MAXOBSERVERS             1058
#define IDC_NG_SECURITY                 1059
#define IDC_NG_RESPAWNS                 1060
#define IDC_GOD_CHAT                    1061
#define IDC_STD_HOST_PASSWD             1062
#define IDC_FIELD1                      1064
#define IDC_FIELD2                      1065
#define IDC_FIELD3                      1066
#define IDC_PXO_REFRESH                 1067
#define IDC_COMBO_VCARD                 1069
#define IDC_COMBO_VMODE                 1070
#define IDC_COMBO_AATYPE                1071
#define ID_CANCEL                       1072
#define ID_OK                           1073
#define IDC_SCORE                       1074
#define IDC_KILL_COUNT                  1075
#define IDC_KILL_COUNT_BH               1076
#define IDC_MSCORE                      1077
#define IDC_MKILL_COUNT                 1078
#define IDC_MKILL_COUNT_BH              1079
#define IDC_MULTILOG                    1084
#define IDC_CON_COUNT                   2000
#define IDC_FRAMECAP_STATIC             2001
#define IDC_GODSTUFF_FPS                2002
#define IDC_PINFO_PING                  2003
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1085
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
