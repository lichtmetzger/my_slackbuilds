/*
 * Copyright (C) Volition, Inc. 1999.  All rights reserved.
 *
 * All source code herein is the property of Volition, Inc. You may not sell 
 * or otherwise commercially exploit the source or things you created based on the 
 * source.
 *
*/



#ifndef _LEVELPAGING_H
#define _LEVELPAGING_H

// Call this and it calls the page in code for all the subsystems
void level_page_in();

#endif	//_LEVELPAGING_H

