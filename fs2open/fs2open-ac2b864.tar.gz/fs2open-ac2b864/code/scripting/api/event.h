
#pragma once

#include "scripting/ade_api.h"

namespace scripting {
	namespace api {
		DECLARE_ADE_OBJ(l_Event, int);
	}
}
