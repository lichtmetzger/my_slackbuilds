#pragma once

#include "globalincs/pstypes.h"
#include "scripting/ade.h"
#include "scripting/ade_api.h"

namespace scripting {
namespace api {

DECLARE_ADE_OBJ(l_Weaponclass, int);

}
}
