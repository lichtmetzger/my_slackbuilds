/*
 * lab.h
 * created by WMCoolmon
 *
 * You may not sell or otherwise commercially exploit the source or things you
 * create based on the source.
 *
 */



void lab_init();
void lab_close();
void lab_do_frame(float frametime);
