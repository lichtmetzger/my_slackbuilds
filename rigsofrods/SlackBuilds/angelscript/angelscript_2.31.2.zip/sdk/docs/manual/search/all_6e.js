var searchData=
[
  ['namespaces',['Namespaces',['../doc_global_namespace.html',1,'doc_script_global']]],
  ['name',['name',['../structas_s_b_c_info.html#a0fec180d222e297a574000aa64bd3af5',1,'asSBCInfo']]],
  ['notifygarbagecollectorofnewobject',['NotifyGarbageCollectorOfNewObject',['../classas_i_script_engine.html#a52a7644b48cbc771e33db5070814f6df',1,'asIScriptEngine']]]
];
