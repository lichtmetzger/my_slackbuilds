#include "#{Panel_Name}.h"

namespace #{Panel_Namespace}
{

	#{Panel_Name}::#{Panel_Name}(MyGUI::Widget* _parent)
	{
		initialiseByAttributes(this, _parent);
	}

	#{Panel_Name}::~#{Panel_Name}()
	{
	}

} // #{Panel_Namespace}